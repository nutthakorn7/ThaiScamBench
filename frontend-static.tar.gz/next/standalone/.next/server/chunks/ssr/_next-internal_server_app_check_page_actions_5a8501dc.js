module.exports=[73868,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_check_page_actions_5a8501dc.js.map
module.exports=[20296,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_report_page_actions_67f5236e.js.map